#include "stm32f10x.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_gpio.h"
#include <stdio.h>
///////////////////////////////////////////include files/////////////////////////////////////////////////////////////
/*******************************************************************************/
/* ???  : RCC_Configuration                                                 */
/* ??    : ???????                                                    */
/* ??    : None                                                              */
/* ??    : None                                                              */
/* ??    : None                                                              */
/********************************************************************************/
void RCC_Configuration(void)
{
//----------????RC??-----------
RCC_DeInit(); //???????
RCC_HSEConfig(RCC_HSE_ON); //????????? 
while(RCC_GetFlagStatus(RCC_FLAG_HSERDY) == RESET); //????????????
FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable); //???????
FLASH_SetLatency(FLASH_Latency_2); //??FLASH???2????
RCC_HCLKConfig(RCC_SYSCLK_Div1); //AHB????????HCLK = SYSCLK
RCC_PCLK2Config(RCC_HCLK_Div1); //??AHB??(PCLK2)PCLK2 =  HCLK
RCC_PCLK1Config(RCC_HCLK_Div2); //??AHB??(PCLK1)PCLK1 = HCLK/2
RCC_PLLConfig(RCC_PLLSource_HSE_Div1,RCC_PLLMul_9); //PLLCLK = 8MHZ * 9 =72MHZ
RCC_PLLCmd(ENABLE); //Enable PLLCLK
while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET); //?? PLLCLK ???
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK); //?? PLL ?????
while(RCC_GetSYSCLKSource()!=0x08); //??????PLL?????
//---------????????--------------------
RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB |RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO | RCC_APB2Periph_USART1,  ENABLE );
}



/*******************************************************************************/
/* ???  : GPIO_USART1_Configuration                                               */
/* ??    : ???GPIO??                                                    */
/* ??    : None                                                              */
/* ??    : None                                                              */
/* ??    : None                                                              */
/*******************************************************************************/
void GPIO_USART1_Configuration(void)
{
GPIO_InitTypeDef GPIO;
 
GPIO.GPIO_Pin =GPIO_Pin_9;
GPIO.GPIO_Speed =GPIO_Speed_50MHz;
GPIO.GPIO_Mode = GPIO_Mode_AF_PP;
GPIO_Init(GPIOA,&GPIO); //?????
GPIO.GPIO_Pin =GPIO_Pin_10;
GPIO.GPIO_Mode = GPIO_Mode_IN_FLOATING;
GPIO_Init(GPIOA,&GPIO); //?????
}

/////////////////////////USART1

void USART1_Configuration(void) //???USART
{ USART_InitTypeDef USART_InitStructure; //??????
USART_InitStructure.USART_BaudRate =  9600; //??9600
USART_InitStructure.USART_WordLength =  USART_WordLength_8b; //????
USART_InitStructure.USART_StopBits =   USART_StopBits_1; //???
USART_InitStructure.USART_Parity =  USART_Parity_No; //????
USART_InitStructure.USART_HardwareFlowControl =  USART_HardwareFlowControl_None; //???
USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx; //??????
USART_Init(USART1, &USART_InitStructure); //??USART_InitStruct???????????USART1???
USART_Cmd(USART1,ENABLE);//??USART??

}


////////////////////////////////FPUTC
int fputc(int ch,FILE *f)
{
//ch??USART1
USART_SendData(USART1, ch);
//??????
while(USART_GetFlagStatus(USART1, USART_FLAG_TC)==RESET) { }
//??ch
return(ch);
}


///////////////////////

int o=38;
int main()
{
	
	RCC_Configuration();
	 
	GPIO_DeInit(GPIOA);
	
	
	
	

}



