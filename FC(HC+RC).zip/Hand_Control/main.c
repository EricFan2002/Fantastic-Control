







////////////////////////////////////////////////////
/*           Hand-Control Part of FC              */
/*           Fantastic Control Group              */
/*                  website:                      */
/*            fantastic-control.win               */
/*          fantastic-control.github.io           */
/*                   Team:FC                      */
/*                 Eric Fan[CN]                   */
/*                 Mr.Cheng[CN]                   */
/*                  Mr.Zhu[CN]                    */
/*          Contact:fty20020322@gmail.com         */
////////////////////////////////////////////////////
/*             WITH LISENCE GPLv2                 */
/*                Mar 11th ,2017                  */
/*              Thanks for comming!               */
////////////////////////////////////////////////////











/////////////////////////////////////////////////Programe/////////////////////////////////////////////////

///////////////////////////////////////////////Include Files//////////////////////////////////////////////
#include <stdio.h>
#include <eric.h>
#include <stm32f10x.h>





//////////////////////////////////////////////////Defines/////////////////////////////////////////////////
#define lcd1602_data_port GPIOE
#define lcd1602_offset 8
#define lcd1602_command_port GPIOB
#define lcd1602_rs 0
#define lcd1602_rw 1
#define lcd1602_en 10

#define ps2_port GPIOC
#define ps2_1_x 0
#define ps2_1_y 1
#define ps2_2_x 2
#define ps2_2_y 3
#define ps2_button_port GPIOD
#define ps2_1_button 7
#define ps2_2_button 6

#define nrf24l01_ce_port GPIOD
#define nrf24l01_ce 8
#define nrf24l01_irq_port GPIOD
#define nrf24l01_irq 9
#define nrf24l01_spi_port GPIOB
#define nrf24l01_nss 12
#define nrf24l01_sck 13
#define nrf24l01_miso 14  //stm32 SPI2-MISO
#define nrf24l01_mosi 15  //stm32 SPI2-MOSI

#define touch_port GPIOD
#define touch_light_mode 5
#define touch_se0 4
#define touch_se1 3
#define touch_se2 2
#define touch_function 1
#define touch_land 0

#define machine_button_port GPIOC
#define machine_button_up 12
#define machine_button_plus 12
#define machine_button_confirm 11
#define machine_button_down 10
#define machine_button_minus 10

#define button_port GPIOD
#define button_emergency 11
#define button_se 10
#define button_function 13

#define buzzer_port GPIOC
#define buzzer 6  //TIM8-CH1

#define led_port GPIOA
#define led_error  3 //TIM5-CH4
#define led_run    2 //TIM5-CH3
#define led_busy   1 //TIM5-CH2
#define led_txdrxd 0 //TIM5-CH1

/*******************************************************************************/
/* function:                                                         */
/* fuc per :                   			            							       */
/* input   :                                                         */
/* output  :                                   							  		   */
/* others  :                                                         */
/********************************************************************************/
///////////////////////////////////////////////////Values/////////////////////////////////////////////////
int val0=0,val1=0,val2=0;
int PRINT_WAY=0;
int include_x_count=0;
int LCD_PLACE_X=0;

/* position of the lcd1602*/
u8 LCD1602_POS[2][16]={0x0 ,0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xA, 0xB, 0xC, 0xD, 0xE, 0xF,
											0x40,0x41,0x42,0x43,0x44,0x45,0x46,0x47,0x48,0x49,0x4A,0x4B,0x4C,0x4D,0x4E,0x4F };
/////////////////////////////////////////////////Base Structs/////////////////////////////////////////////
EXTI_InitTypeDef EXTI_InitStructure;
NVIC_InitTypeDef NVIC_InitStructure;

//////////////////////////////////////////////////Programme///////////////////////////////////////////////
/*******************************************************************************/
/* function: rcc_init															 	 							 						*/
/* fuc per : to get rcc ready                          			                   */
/* input   : none                                                              */
/* output  : none                             													       */
/* others  : None                                                              */
/********************************************************************************/
void rcc_init()
{
	RCC->AHBENR=0XFFFFFFFF;
	RCC->APB1ENR=0XFFFFFFFF;
	RCC->APB2ENR=0XFFFFFFFF;
	
	RCC_DeInit(); //reset
	RCC_HSEConfig(RCC_HSE_OFF); //use hsi
	FLASH_SetLatency(FLASH_Latency_2); //for 64mhz
	RCC_HCLKConfig(RCC_SYSCLK_Div1); //HCLK = SYSCLK
	RCC_PCLK2Config(RCC_HCLK_Div1); //(PCLK2)PCLK2 =  HCLK
	RCC_PCLK1Config(RCC_HCLK_Div2); //(PCLK1)PCLK1 = HCLK/2
	RCC_PLLConfig(RCC_PLLSource_HSI_Div2,RCC_PLLMul_16); //PLLCLK = 8MHZ * 16 / 2 =64MHZ
	RCC_PLLCmd(ENABLE); //Enable PLLCLK
	while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET); //wait PLLCLK 
	RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK); //use PLL
	while(RCC_GetSYSCLKSource()!=0x08); //use PLL

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB |RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO | RCC_APB2Periph_USART1,  ENABLE );
	RCC->CFGR|=0X3<<14;
}
/*******************************************************************************/
/* function: gpio_init		                                                     */
/* fuc per : to get all gpio ready                     			                   */
/* input   : none                                                              */
/* output  : none                             													       */
/* others  : None                                                              */
/********************************************************************************/
void gpio_init()
{
	 /*   lcd1602   */
	for(val0=lcd1602_offset;val0<(lcd1602_offset+8);val0++)
		Set_Pin_Dir(lcd1602_data_port,val0,PIN_OUT_PP);
	Set_Pin_Dir(lcd1602_command_port,lcd1602_en,PIN_OUT_PP);
	Set_Pin_Dir(lcd1602_command_port,lcd1602_rs,PIN_OUT_PP);
	Set_Pin_Dir(lcd1602_command_port,lcd1602_rw,PIN_OUT_PP);
	
	/*     ps2      */
	Set_Pin_Dir(ps2_port,ps2_1_x,PIN_IN_AD);
	Set_Pin_Dir(ps2_port,ps2_1_y,PIN_IN_AD);
	Set_Pin_Dir(ps2_port,ps2_2_x,PIN_IN_AD);
	Set_Pin_Dir(ps2_port,ps2_2_y,PIN_IN_AD);
	Set_Pin_Dir(ps2_button_port,ps2_1_button,PIN_IN_AD);
	Set_Pin_Dir(ps2_button_port,ps2_2_button,PIN_IN_AD);
	
	/*   nrf24l01   */
	Set_Pin_Dir(nrf24l01_spi_port,nrf24l01_nss,PIN_AF_PP);
	Set_Pin_Dir(nrf24l01_spi_port,nrf24l01_mosi,PIN_AF_PP);
	Set_Pin_Dir(nrf24l01_spi_port,nrf24l01_miso,PIN_AF_PP);
	Set_Pin_Dir(nrf24l01_spi_port,nrf24l01_sck,PIN_AF_PP);
	Set_Pin_Dir(nrf24l01_irq_port,nrf24l01_irq,PIN_IN);
	Set_Pin_Dir(nrf24l01_ce_port,nrf24l01_ce,PIN_OUT_PP);
	
	/* touch button */
	Set_Pin_Dir(touch_port,touch_function,PIN_IN_WITH_PULL);
	Set_Pin_Dir(touch_port,touch_land,PIN_IN_WITH_PULL);
	Set_Pin_Dir(touch_port,touch_light_mode,PIN_IN_WITH_PULL);
	Set_Pin_Dir(touch_port,touch_se0,PIN_IN_WITH_PULL);
	Set_Pin_Dir(touch_port,touch_se1,PIN_IN_WITH_PULL);
	Set_Pin_Dir(touch_port,touch_se2,PIN_IN_WITH_PULL);
	
	/*machine button*/
	Set_Pin_Dir(machine_button_port,machine_button_up,PIN_IN_WITH_PULL);
	Set_Pin_State(machine_button_port,machine_button_up,1);
	Set_Pin_Dir(machine_button_port,machine_button_confirm,PIN_IN_WITH_PULL);
	Set_Pin_State(machine_button_port,machine_button_confirm,1);
	Set_Pin_Dir(machine_button_port,machine_button_down,PIN_IN_WITH_PULL);
	Set_Pin_State(machine_button_port,machine_button_down,1);
	
	/* other button */
	Set_Pin_Dir(button_port,button_emergency,PIN_IN_WITH_PULL);
	Set_Pin_State(button_port,button_emergency,1);
	Set_Pin_Dir(button_port,button_function,PIN_IN_WITH_PULL);
	Set_Pin_State(button_port,button_function,1);
	Set_Pin_Dir(button_port,button_se,PIN_IN_WITH_PULL);
	Set_Pin_State(button_port,button_se,1);
	
	/*    buzzer    */
	Set_Pin_Dir(buzzer_port,buzzer,PIN_AF_PP);
	
	/*     leds     */
	Set_Pin_Dir(led_port,led_busy,PIN_AF_PP);
	Set_Pin_Dir(led_port,led_error,PIN_AF_PP);
	Set_Pin_Dir(led_port,led_run,PIN_AF_PP);
	Set_Pin_Dir(led_port,led_txdrxd,PIN_AF_PP);
	/*
	Set_Pin_State(led_port,led_busy,1);
	Set_Pin_State(led_port,led_error,1);
	Set_Pin_State(led_port,led_run,1);
	Set_Pin_State(led_port,led_txdrxd,1);
	*/
	
}

/*******************************************************************************/
/* function: NVIC_init        		                                             */
/* fuc per : to get nvic ready to break                			                   */
/* input   : none                                                              */
/* output  : none                             													       */
/* others  : None                                                              */
/********************************************************************************/
void NVIC_init()
{
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
	//TIM6 breaking at 20ms
	NVIC_InitStructure.NVIC_IRQChannel = TIM6_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	
}

/*******************************************************************************/
/* function: TIM6_break_pwn_init                                               */
/* fuc per : to get tim6 ready for pwm                 			                   */
/* input   : none                                                              */
/* output  : none                             													       */
/* others  : None                                                              */
/********************************************************************************/
void TIM6_break_pwn_init()
{
	TIM6->CR1=0X00; //RESET
	TIM6->CR1&=~(0X01);		//DISABLE TIM6
	TIM6->CR1&=~(0X01<<4);//DIR_UP
	TIM6->CR1|=0X01<<7; 	//PRELOAD ON TIM6 ENABLED
	
	TIM6->ARR=50;//200->10()pwm speed 1->20ms x 255
	
	TIM6->PSC=6400; //10K FRQ   
	
	//200MS ONECE
	
	//TIM6->EGR|=0X01<<6;
	//TIM6->EGR|=0X01;
	TIM6->DIER|=0X01<<6;
	TIM6->DIER|=0X01;
	TIM6->SR|=0X01<<6;

	TIM6->CNT=0;
	TIM6->CR1=0X01;//enable
}
/*******************************************************************************/
/* function: TIM6_IRQHandler                                                   */
/* fuc per : handle tim6 breakings                    			                   */
/* input   : none                                                              */
/* output  : none                             													       */
/* others  : None                                                              */
/********************************************************************************/
void TIM6_IRQHandler()
{
	if(TIM6->SR&0x01)
	{
		TIM6->SR=0x0;
		if(val1==0)
		{
			TIM5->CCR1+=1;
			TIM5->CCR2+=1;
			TIM5->CCR3+=1;
			TIM5->CCR4+=1;
			if(TIM5->CCR1==255) val1=1;
		}
		else
		{
			TIM5->CCR1-=1;
			TIM5->CCR2-=1;
			TIM5->CCR3-=1;
			TIM5->CCR4-=1;
			if(TIM5->CCR1==0) val1=0;
		}
	}
}

/*******************************************************************************/
/* function: TIM5_pwm1_init                                                    */
/* fuc per : get TIM5 ready for pwm leds               			                   */
/* input   : none                                                              */
/* output  : none                             													       */
/* others  : None                                                              */
/********************************************************************************/
void TIM5_pwm1_init(void)
{
	
	TIM5->CR1=0x0000;
	
	TIM5->CR1|=0x01<<7;//RELOAD ON TIM5
	TIM5->CR1|=0x00<<4; //DIR_UP
	
	TIM5->CCMR1=0x00;
	
	TIM5->CCMR1|=0x01<<3; //RELOAD ON CH1
	TIM5->CCMR1|=0x01<<11; //RELOAD ON CH2
	TIM5->CCMR2|=0x01<<3; //RELOAD ON CH3
	TIM5->CCMR2|=0x01<<11; //RELOAD ON CH4
	
	TIM5->CCMR1|=0x06<<4; //PWM1 ON CH1
	TIM5->CCMR1|=0x06<<12; //PWM1 ON CH2
	TIM5->CCMR2|=0x06<<4; //PWM1 ON CH3
	TIM5->CCMR2|=0x06<<12; //PWM1 ON CH4

	TIM5->CCER=0x00;
	TIM5->CCER|=0x01<<0; //CC CH1 ENB
	TIM5->CCER|=0x01<<4; //CC CH2 ENB
	TIM5->CCER|=0x01<<8; //CC CH3 ENB
	TIM5->CCER|=0x01<<12;//CC CH4 ENB

	TIM5->ARR=255; //TARGET RELOAD VAL_255

	TIM5->PSC=120; //DIV3600

	TIM5->CR1|=0x01; //ENB TIM5
	
	TIM5->CCR1=0;//RESET PWM VAL
	TIM5->CCR2=0;//RESET PWM VAL
	TIM5->CCR3=0;//RESET PWM VAL
	TIM5->CCR4=0;//RESET PWM VAL

}

/*******************************************************************************/
/* function: LCD1602_CMD		                                                   */
/* fuc per : send a command to lcd1602                			                   */
/* input   : char cmd                                                          */
/* output  : none                             													       */
/* others  : None                                                              */
/********************************************************************************/
void LCD1602_CMD(char cmd)
{
	/*ready for cmd*/
	Set_Pin_State(lcd1602_command_port,lcd1602_en,0);
	Set_Pin_State(lcd1602_command_port,lcd1602_rw,0);
	Set_Pin_State(lcd1602_command_port,lcd1602_rs,0);
	/*put cmd into port*/
	lcd1602_data_port->ODR&=~((0xFF)<<lcd1602_offset);
	lcd1602_data_port->ODR|=((cmd)<<lcd1602_offset);
	delay_ms(1);
	Set_Pin_State(lcd1602_command_port,lcd1602_en,1);
	delay_ms(1);
	Set_Pin_State(lcd1602_command_port,lcd1602_en,0);
	
}

/*******************************************************************************/
/* function: LCD1602_CMD		                                                   */
/* fuc per : send a char data to lcd1602               			                   */
/* input   : char data                                                         */
/* output  : none                             													       */
/* others  : None                                                              */
/********************************************************************************/
void LCD1602_DATA(char data)
{
	/*ready for data*/
	Set_Pin_State(lcd1602_command_port,lcd1602_en,0);
	Set_Pin_State(lcd1602_command_port,lcd1602_rw,0);
	Set_Pin_State(lcd1602_command_port,lcd1602_rs,1);
	/*put data into port*/
	lcd1602_data_port->ODR&=~((0xFF)<<lcd1602_offset);
	lcd1602_data_port->ODR|=((data)<<lcd1602_offset);
	Set_Pin_State(lcd1602_command_port,lcd1602_en,1);
	delay_ms(1);
	Set_Pin_State(lcd1602_command_port,lcd1602_en,0);
	delay_ms(1);
	
}

/*******************************************************************************/
/* function: LCD1602_BUSY		                                                   */
/* fuc per : wait lcd1602							                			                   */
/* input   : none		                                                           */
/* output  : none                             													       */
/* others  : None                                                              */
/********************************************************************************/
void LCD1602_BUSY()
{
	//return;
	Set_Pin_State(lcd1602_command_port,lcd1602_en,0);
	Set_Pin_Dir(lcd1602_data_port,(lcd1602_offset+7),PIN_IN_WITH_PULL);
	Set_Pin_State(lcd1602_data_port,(lcd1602_offset+7),1);
	Set_Pin_State(lcd1602_command_port,lcd1602_en,1);
	delay_ms(1);
	while(Get_Pin_State(lcd1602_data_port,(lcd1602_offset+7))==1);
	delay_ms(1);
	Set_Pin_Dir(lcd1602_data_port,(lcd1602_offset+7),PIN_OUT_PP);
	
}

/*******************************************************************************/
/* function: LCD1602_RESET	                                                   */
/* fuc per : reset lcd and set 8bit,2x16 chars         			                   */
/* input   : none		                                                           */
/* output  : none                             													       */
/* others  : None                                                              */
/********************************************************************************/
void LCD1602_RESET()
{
	LCD1602_CMD(0x38);
	LCD1602_BUSY();
	LCD1602_CMD(0x38);
	LCD1602_BUSY();
	LCD1602_CMD(0x38);
	LCD1602_BUSY();
	LCD1602_CMD(0x38);
	LCD1602_BUSY();
	LCD1602_CMD(0x0c);
	LCD1602_BUSY();
	LCD1602_CMD(0x06);
	LCD1602_BUSY();
	LCD1602_CMD(0x01);
	LCD1602_BUSY();
	
}

/*******************************************************************************/
/* function: LCD1602_READY		                                                 */
/* fuc per : get lcd1602 ready for some postition      			                   */
/* input   : the position x and y                                              */
/* output  : none                             													       */
/* others  : None                                                              */
/********************************************************************************/
void LCD1602_READY(int pos_y,int pos_x)
{
	LCD1602_CMD(0x80|LCD1602_POS[pos_y][pos_x]);
	
}
/*******************************************************************************/
/* function: fputc		                                          				       */
/* fuc per : redirect the printf								      			                   */
/* input   : ch file						                                               */
/* output  : none                             													       */
/* others  : None                                                              */
/********************************************************************************/
int fputc(int ch,FILE *f)
{
	if(PRINT_WAY==0)
	{
		/*Send by UART*/
		USART_SendData(USART1, ch);
		while(USART_GetFlagStatus(USART1, USART_FLAG_TC)==RESET) { }

	}
	else if(PRINT_WAY==1)
	{
		/*Send by LCD*/
		LCD1602_DATA(ch);
		/*if caculate the length of string*/
		if(include_x_count==1)
			LCD_PLACE_X++;
		
	}
	else if(PRINT_WAY==2)
	{
		//
	}
	return(ch);
}
/*******************************************************************************/
/* function: hardware_init                                                     */
/* fuc per : to get all things ready                   			                   */
/* input   : none                                                              */
/* output  : none                             													       */
/* others  : None                                                              */
/********************************************************************************/
void hardware_init()
{
	rcc_init();
	gpio_init();
	NVIC_init();
	//TIM6_break_pwn_init();
	TIM5_pwm1_init();
	TIM3_COUNT_INIT();
	
	LCD1602_RESET();
}

///////////////////////////////////////////////Main Programme/////////////////////////////////////////////
int main(){
	hardware_init();
	LCD1602_READY(0,0);
	PRINT_WAY=1;
	printf("hello!");
	while(1);
}

/////////////////////////////////////////////////Programe/////////////////////////////////////////////////
